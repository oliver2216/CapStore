package com.capgemini.capstore.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class CapStoreController {

	
}
