package com.capgemini.capstore.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CapStoreEncryptionApplication {

	public static void main(String[] args) {
		SpringApplication.run(CapStoreEncryptionApplication.class, args);
	}

}
