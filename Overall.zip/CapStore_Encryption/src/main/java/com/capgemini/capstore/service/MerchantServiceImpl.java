package com.capgemini.capstore.service;

import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.beans.MerchantProduct;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.dao.CapStoreMerchant;
import com.capgemini.capstore.dao.CapStoreMerchantProduct;
import com.capgemini.capstore.dao.CapStoreProduct;

@Service
public class MerchantServiceImpl implements IMerchantService{

	@Autowired
	CapStoreProduct products;
	
	@Autowired
	CapStoreMerchantProduct productMerchant;
	
	@Autowired
	CapStoreMerchant merchant;
	public String addProduct(MerchantProduct merchantProduct) {
		
		try {
			Product product= products.findById(merchantProduct.getProduct().getProductModel()).get();
			String id=String.valueOf( product.getProductId()+"_"+merchantProduct.getMerchant().getMerchantId());
			try{
				productMerchant.findById(id).get();
				return "Product already present";
			}
			catch(NoSuchElementException e) {
				
				productMerchant.save(merchantProduct);
				return "Product added successfully";
			}
				
		}
		catch(NoSuchElementException e) {
		
			products.save(merchantProduct.getProduct());
			productMerchant.save(merchantProduct);
			return "Product added successfully";
		}
		
	}
	
	public String removeProduct(String merchantProductId) {
		
		productMerchant.deleteById(merchantProductId);
		return "Product Removed Successfully";
		
	}
	
	public String updateProduct(MerchantProduct merchantProduct) {
		
		productMerchant.save(merchantProduct);
		
		return "Product updated successfully";
	}
	
	
	public String updateProductQuantity(MerchantProduct merchantProduct) {
		
		if(productMerchant.findById(String.valueOf(merchantProduct.getProduct().getProductId()+"_"+merchantProduct.getMerchant().getMerchantId())).get().getProductQuantity()-merchantProduct.getProductQuantity()>=0) {
			
			productMerchant.save(merchantProduct);
			return "Quantity updated successfully";
		}
		else {
			return "insufficient product quantity";
		}
	
	}

	@Override
	public Merchant getMerchant(String merchantId) {
		
		return merchant.findBymerchantEmail(merchantId);
	}
	
	
	
}
