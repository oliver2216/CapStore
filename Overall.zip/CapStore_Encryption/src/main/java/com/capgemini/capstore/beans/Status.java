package com.capgemini.capstore.beans;

public enum Status {
	
	Current, Valid,Reply;
	

}
