package com.capgemini.capstore.controller;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.beans.MerchantProduct;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.service.IMerchantService;

@RestController
public class CapStoreMerchantController {
	
	@Autowired
	IMerchantService merchantServices;
	
	@RequestMapping(method=RequestMethod.POST, value = "/addProduct/{productQuantity}/{productPrice}")
	
	public String addProduct(@RequestBody Product product,@PathVariable int productQuantity, @PathVariable double productPrice,HttpServletRequest request) {
		System.out.println("hello");
//		HttpSession session = request.getSession();
//		String merchantId = (String) session.getAttribute("userId");
		Merchant merchant = merchantServices.getMerchant("abc@gmail.com");
		MerchantProduct merchantProduct = new MerchantProduct();
		merchantProduct.setId(String.valueOf( product.getProductId()+"_"+merchant.getMerchantId()));
		merchantProduct.setMerchant(merchant);
		merchantProduct.setProduct(product);
		merchantProduct.setProductPrice(productPrice);
		merchantProduct.setProductQuantity(productQuantity);
		return merchantServices.addProduct(merchantProduct);

	}

	@RequestMapping(value = "/removedProduct")
	public String removeProduct(@RequestBody Product product,HttpServletRequest request) {
		
		HttpSession session = request.getSession();
		String merchantId = (String)session.getAttribute("userId");
		Merchant merchant = merchantServices.getMerchant(merchantId);
		MerchantProduct merchantProduct = new MerchantProduct();
		merchantProduct.setMerchant(merchant);
		merchantProduct.setProduct(product);
		merchantProduct.setProductPrice(0);
		merchantProduct.setProductQuantity(0);
		return merchantServices.removeProduct(merchantProduct);
	
	}
	
	@RequestMapping(value = "/updateProduct/{productQuantity}/{productPrice}")
	public String updateProduct(@RequestBody Product product,@PathVariable int productQuantity, @PathVariable double productPrice,HttpServletRequest request) {
		
		HttpSession session = request.getSession();
		String merchantId = (String) session.getAttribute("userId");
		Merchant merchant = merchantServices.getMerchant(merchantId);
		MerchantProduct merchantProduct = new MerchantProduct();
		merchantProduct.setMerchant(merchant);
		merchantProduct.setProduct(product);
		merchantProduct.setProductPrice(productPrice);
		merchantProduct.setProductQuantity(productQuantity);
		return merchantServices.updateProduct(merchantProduct);

	}
	
	@RequestMapping(value = "/updateProductQuantity/{productQuantity}/{productPrice}")
	public String updateProductQuantity(@RequestBody Product product,@PathVariable int productQuantity, @PathVariable double productPrice,HttpServletRequest request) {
		
		HttpSession session = request.getSession();
		String merchantId = (String)session.getAttribute("userId");
		Merchant merchant = merchantServices.getMerchant(merchantId);
		MerchantProduct merchantProduct = new MerchantProduct();
		merchantProduct.setMerchant(merchant);
		merchantProduct.setProduct(product);
		merchantProduct.setProductPrice(productPrice);
		merchantProduct.setProductQuantity(productQuantity);
		return merchantServices.updateProduct(merchantProduct);

	}

	
}