package com.capgemini.capstore.service;

import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.beans.MerchantProduct;

@Service
public interface IMerchantService {
	
	public String addProduct(MerchantProduct merchantProduct);
	public String removeProduct(MerchantProduct merchantProduct);
	public String updateProduct(MerchantProduct merchantProduct);
	public String updateProductQuantity(MerchantProduct merchantProduct) ;
	public Merchant getMerchant(String merchantId);
	

}
