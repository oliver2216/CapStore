package com.capgemini.capstore.service;

import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.beans.MerchantProduct;

public interface IMerchantService {
	
	public String addProduct(MerchantProduct merchantProduct);
	public String removeProduct(MerchantProduct merchantProduct);
	public String updateProduct(MerchantProduct merchantProduct);
	public String updateProductQuantity(MerchantProduct merchantProduct) ;
	public Merchant getMerchant(String merchantId);
	

}
